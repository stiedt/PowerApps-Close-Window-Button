var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad=function(e){var t={};function n(i){if(t[i])return t[i].exports;var o=t[i]={i:i,l:!1,exports:{}};return e[i].call(o.exports,o,o.exports,n),o.l=!0,o.exports}return n.m=e,n.c=t,n.d=function(e,t,i){n.o(e,t)||Object.defineProperty(e,t,{enumerable:!0,get:i})},n.r=function(e){"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},n.t=function(e,t){if(1&t&&(e=n(e)),8&t)return e;if(4&t&&"object"==typeof e&&e&&e.__esModule)return e;var i=Object.create(null);if(n.r(i),Object.defineProperty(i,"default",{enumerable:!0,value:e}),2&t&&"string"!=typeof e)for(var o in e)n.d(i,o,function(t){return e[t]}.bind(null,o));return i},n.n=function(e){var t=e&&e.__esModule?function(){return e.default}:function(){return e};return n.d(t,"a",t),t},n.o=function(e,t){return Object.prototype.hasOwnProperty.call(e,t)},n.p="",n(n.s=0)}([
/*!******************************!*\
  !*** ./CanvasClose/index.ts ***!
  \******************************/
/*! no static exports found */
/*! all exports used */
/*! ModuleConcatenation bailout: Module is not an ECMAScript module */function(e,t,n){"use strict";Object.defineProperty(t,"__esModule",{value:!0}),t.CanvasClose=void 0;var i=function(){function e(){}return e.prototype.init=function(e,t,n,i){this._container=i,this._context=e,this.theNotifyOutputChanged=t,this.eventSubmitClicked=this.submitClicked.bind(this),this._eleMainContainer=document.createElement("div"),this._eleMainContainer.className="mydiv",this._eleButton=document.createElement("button"),this._eleButton.className="canvasAppButton",this._eleButton.innerHTML="Close",this._eleButton.addEventListener("click",this.eventSubmitClicked),this._eleMainContainer.appendChild(this._eleButton),this._container.appendChild(this._eleMainContainer)},e.prototype.submitClicked=function(e){close()},e.prototype.updateView=function(e){},e.prototype.getOutputs=function(){return{}},e.prototype.destroy=function(){},e}();t.CanvasClose=i}]);
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('CanvasAppClose.CanvasClose', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.CanvasClose);
} else {
	var CanvasAppClose = CanvasAppClose || {};
	CanvasAppClose.CanvasClose = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.CanvasClose;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}